package cn.ipaynow.wx;

import com.ipaynow.wechatpay.plugin.view.IpaynowLoading;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;

public class MyLoading implements IpaynowLoading{
    ProgressDialog dialog;
    public MyLoading(Context context) {
        dialog = new ProgressDialog(context);
    }
    @Override
    public void setLoadingMsg(String arg0) {
        Log.i("TAG", "msg = "+arg0);
        dialog.setMessage(arg0);
    }
    
    @Override
    public Object show() {
        dialog.show();
        return this;
    }
    @Override
    public void dismiss() {
        dialog.dismiss();
    }
    
    @Override
    public boolean isShowing() {
        return dialog.isShowing();
    }




}

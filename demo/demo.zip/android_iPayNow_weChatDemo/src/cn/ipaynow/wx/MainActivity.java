package cn.ipaynow.wx;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.ipaynow.wechatpay.plugin.api.WechatPayPlugin;
import com.ipaynow.wechatpay.plugin.manager.route.dto.ResponseParams;
import com.ipaynow.wechatpay.plugin.manager.route.impl.ReceivePayResult;
import com.ipaynow.wechatpay.plugin.utils.PreSignMessageUtil;
import com.ipaynow.wechatpay.plugin.view.IpaynowLoading;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends Activity implements ReceivePayResult {
    // 现在支付测试用生成签名接口
    @SuppressWarnings("unused")
    private static final String GETORDERMESSAGE_URL = "http://posp.ipaynow.cn/ZyPluginPaymentTest_PAY/api/pay2.php";
    //测试用现在支付应用账号
    private static final String mAppID = "1408709961320306";
    private static final String mKey = "0nqIDgkOnNBD6qoqO5U68RO1fNqiaisg";
    private static String preSignStr;//待签名串

    private EditText mAppIdET;
    private EditText mAppKeyET;
    private EditText mAmtET;
    private EditText mReservedET;
    private EditText mOrderDatailET;
    private EditText mUrlET;
    private EditText mOrderNameET;
    private RadioGroup mLimitPayRG;
    
    private WechatPayPlugin weChatPlugin;
    private IpaynowLoading loading;
    private PreSignMessageUtil preSign = new PreSignMessageUtil();//待签名串生成工具

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 插件初始化
        weChatPlugin = WechatPayPlugin.getInstance().init(this);
        initUI();
    }

    private void initUI() {
        // 可自定义loading界面
        loading = weChatPlugin.getDefaultLoading();
        mAmtET = (EditText) findViewById(R.id.et_amt);
        mAppIdET = (EditText) findViewById(R.id.et_appid);
        mAppIdET.setText(mAppID);
        mAppKeyET = (EditText) findViewById(R.id.et_appKey);
        mAppKeyET.setText(mKey);
        mReservedET = (EditText) findViewById(R.id.et_resever);
        mUrlET = (EditText) findViewById(R.id.et_url);
        mOrderNameET = (EditText) findViewById(R.id.et_name);
        mOrderDatailET = (EditText) findViewById(R.id.et_detal);
        mLimitPayRG = (RadioGroup) findViewById(R.id.rg_limitpay);
    }

    /**
     * 触发支付事件
     * 
     * @param v
     */
    public void goToPay(View v) {
        pay();
    }

    /**
     * 处理支付事件
     */
    private void pay() {
        ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = manager.getActiveNetworkInfo();
        if (TextUtils.isEmpty(mAmtET.getText().toString())) {
            Toast.makeText(this, "请输入金额", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(mAppIdET.getText().toString())) {
            Toast.makeText(this, "请输入appId", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(mAppKeyET.getText().toString())) {
            Toast.makeText(this, "请输入appKey", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(mOrderDatailET.getText().toString())) {
            Toast.makeText(this, "请输入订单详情", Toast.LENGTH_SHORT).show();
            return;
        }
        if (info == null || !info.isConnected()) {
            Toast.makeText(this, "请检查手机网络", Toast.LENGTH_LONG).show();
            return;
        }
        String no = new SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(new Date());
        // 创建订单列表
        prePayMessage(no, no);
        loading.setLoadingMsg("创建订单...");
        loading.show();
        // 生成待签名串
        preSignStr = preSign.generatePreSignMessage();
        GetMessage gM = new GetMessage();
        // gM.execute("paydata=" + MerchantTools.urlEncode(preSignStr));
        gM.execute(preSignStr);

    }

    /**
     * 创建订单
     * 
     * @param mhtOrderNo
     *            商户订单号
     * @param mhtOrderStartTime
     *            创建订单时间
     */
    private void prePayMessage(String mhtOrderNo, String mhtOrderStartTime) {
        preSign.appId = mAppIdET.getText().toString();
        preSign.mhtOrderNo = mhtOrderNo;
        preSign.mhtOrderName = mOrderNameET.getText().toString();
        preSign.mhtOrderAmt = mAmtET.getText().toString();
        preSign.mhtOrderDetail = mOrderDatailET.getText().toString();
        preSign.mhtOrderStartTime = mhtOrderStartTime;
        preSign.mhtReserved = mReservedET.getText().toString();
        preSign.notifyUrl = mUrlET.getText().toString();
        preSign.mhtOrderType = "01";
        preSign.mhtCurrencyType = "156";
        preSign.mhtOrderTimeOut = "3600";
        preSign.mhtCharset = "UTF-8";
        preSign.payChannelType = "13";
        preSign.consumerId = "456123";
        preSign.consumerName = "yuyang";
        if(mLimitPayRG.getCheckedRadioButtonId()==R.id.rb_sup){
            preSign.mhtLimitPay = null;
        }else{
            preSign.mhtLimitPay = "no_credit";
        }
    }

    /**
     * 子线程获取签名，主线程中调起支付插件
     */
    public class GetMessage extends AsyncTask<String, Integer, String> {
        protected String doInBackground(String... params) {
            String msg = params[0];
            // String needcheckmsg = HttpUtil.post(GETORDERMESSAGE_URL, msg);
            // 注意：这里只是在前端模拟生成签名，正式发布时请在后台生成签名。
            String needcheckmsg = "mhtSignature=" + Md5Util.md5(msg + "&" + Md5Util.md5(mAppKeyET.getText().toString()))
                    + "&mhtSignType=MD5";
            needcheckmsg = MainActivity.preSignStr + "&" + needcheckmsg;
            return needcheckmsg;
        }

        @SuppressWarnings("deprecation")
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            // 如果商户保留域中包含特殊字符：& 请在调起插件时对该字段的value进行一次utf8编码
            if (result.contains(preSign.mhtReserved) && !TextUtils.isEmpty(preSign.mhtReserved)) {
                result = result.replace(preSign.mhtReserved, URLEncoder.encode(preSign.mhtReserved));
            }
            loading.dismiss();
            Log.i("收到的请求信息", result);
            weChatPlugin
//            .setCustomDialog(new MyLoading(MainActivity.this))
            .setCallResultReceiver(MainActivity.this)/* 传入继承了通知接口的类 */
            .pay(result);// 传入请求数据
        }
    }

    /**
     * 支付回调接口实现
     */
    @Override
    public void onIpaynowTransResult(ResponseParams resp) {
        if (resp == null) {
            return;
        }
        String respCode = resp.respCode;
        String errorCode = resp.errorCode;
        String respMsg = resp.respMsg;
        StringBuilder temp = new StringBuilder();
        if (respCode.equals("00")) {
            temp.append("交易状态:成功");
        } else if (respCode.equals("02")) {
            temp.append("交易状态:取消");
        } else if (respCode.equals("01")) {
            temp.append("交易状态:失败").append("\n").append("错误码:").append(errorCode).append("原因:" + respMsg);
        } else if (respCode.equals("03")) {
            temp.append("交易状态:未知").append("\n").append("原因:" + respMsg);
        } else {
            temp.append("respCode=").append(respCode).append("\n").append("respMsg=").append(respMsg);
        }
        Toast.makeText(this, temp.toString(), Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onDestroy() {
        weChatPlugin.onActivityDestroy();
        super.onDestroy();
    }
}
